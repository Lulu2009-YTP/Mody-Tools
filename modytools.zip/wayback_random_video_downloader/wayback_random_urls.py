import requests
import random

def get_random_wayback_youtube_url():
    WAYBACK_API = 'http://web.archive.org/cdx/search/cdx?url=youtube.com/watch&output=json&fl=original&limit=100'
    response = requests.get(WAYBACK_API)
    
    if response.status_code == 200:
        data = response.json()
        if len(data) > 1:
            # Skip the first entry as it's the header
            random_url = random.choice(data[1:])
            return random_url[0]
    return None
