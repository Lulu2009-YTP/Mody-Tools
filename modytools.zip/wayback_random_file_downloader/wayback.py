import requests
import random

WAYBACK_API = "http://web.archive.org/cdx/search/cdx?url=*.*&output=json&filter=statuscode:200"

def get_random_url(file_type):
    """Fetches random links from the Wayback Machine for a specific file type."""
    query = f"{WAYBACK_API}&filter=mimetype:application/{file_type}&limit=100"
    response = requests.get(query).json()

    if len(response) > 1:
        random_entry = random.choice(response[1:])
        return f"http://web.archive.org/web/{random_entry[1]}/{random_entry[2]}"
    return None
