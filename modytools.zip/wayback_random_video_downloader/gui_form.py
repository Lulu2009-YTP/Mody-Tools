import tkinter as tk
from downloader import get_random_youtube_url, download_video

class WaybackDownloaderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Wayback Random Video Downloader")

        self.label = tk.Label(root, text="Click to download a random video from Wayback Machine")
        self.label.pack(pady=10)

        self.download_button = tk.Button(root, text="Download Random Video", command=self.download_random_video)
        self.download_button.pack(pady=10)

    def download_random_video(self):
        url = get_random_youtube_url()
        if url:
            self.label.config(text=f"Downloading video from: {url}")
            download_video(url)
        else:
            self.label.config(text="No valid YouTube URL found.")

if __name__ == "__main__":
    root = tk.Tk()
    app = WaybackDownloaderApp(root)
    root.mainloop()
