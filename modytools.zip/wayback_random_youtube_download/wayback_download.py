import random
import requests
import yt_dlp
import tkinter as tk
from tkinter import messagebox

# Function to fetch random YouTube URLs from Wayback Machine
def fetch_random_wayback_url():
    wayback_api = "http://archive.org/wayback/available"
    youtube_base = "https://www.youtube.com/"
    
    # Parameters for the Wayback Machine search (randomized timestamp)
    timestamp = random.randint(2005, 2023)
    params = {
        'url': youtube_base,
        'timestamp': timestamp
    }

    response = requests.get(wayback_api, params=params).json()
    
    if 'archived_snapshots' in response and response['archived_snapshots']:
        snapshot = response['archived_snapshots']['closest']
        return snapshot['url']
    else:
        return None

# Function to download YouTube video
def download_video(url):
    ydl_opts = {
        'format': 'best',
        'outtmpl': 'downloaded_video.%(ext)s',
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])

# GUI Form to interact with the user
def gui():
    def on_download_click():
        random_url = fetch_random_wayback_url()
        if random_url:
            messagebox.showinfo("Random URL", f"Found URL: {random_url}")
            download_video(random_url)
        else:
            messagebox.showwarning("Error", "No archived YouTube video found.")

    root = tk.Tk()
    root.title("Wayback YouTube Random Downloader")

    download_button = tk.Button(root, text="Download Random YouTube Video", command=on_download_click)
    download_button.pack(pady=20)

    root.mainloop()

if __name__ == "__main__":
    gui()
