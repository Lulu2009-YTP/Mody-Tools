import requests
from bs4 import BeautifulSoup
from waybackpy import WaybackMachineCDXServerAPI
import urllib.parse
import os
from tqdm import tqdm

# Configuration
WAYBACK_URL = "http://web.archive.org/cdx/search/cdx?url={}&from={}&to={}&filter=statuscode:200&output=json"
SEARCH_QUERY = "video"
ARCHIVE_LIMIT = 100  # Number of results to retrieve
DOWNLOAD_DIR = "downloads"  # Directory to save downloaded videos

# Create download directory if not exists
if not os.path.exists(DOWNLOAD_DIR):
    os.makedirs(DOWNLOAD_DIR)

def fetch_wayback_links(query, limit=ARCHIVE_LIMIT):
    url = WAYBACK_URL.format(urllib.parse.quote(query), '20000101', '20231231')
    response = requests.get(url)
    response.raise_for_status()
    data = response.json()
    links = [item[1] for item in data[1:limit+1] if item[1].endswith(('.mp4', '.avi', '.mov'))]
    return links

def download_video(url, filename):
    response = requests.get(url, stream=True)
    response.raise_for_status()
    
    total_size = int(response.headers.get('content-length', 0))
    with open(filename, 'wb') as file, tqdm(
        desc=filename,
        total=total_size,
        unit='B',
        unit_scale=True,
        unit_divisor=1024,
    ) as bar:
        for chunk in response.iter_content(chunk_size=1024):
            file.write(chunk)
            bar.update(len(chunk))

def main():
    video_links = fetch_wayback_links(SEARCH_QUERY)
    for idx, link in enumerate(video_links):
        filename = os.path.join(DOWNLOAD_DIR, f"video_{idx+1}.mp4")
        print(f"Downloading {link} to {filename}")
        download_video(link, filename)
        print(f"Downloaded {filename}")

if __name__ == "__main__":
    main()
