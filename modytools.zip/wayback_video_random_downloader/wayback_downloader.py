import requests
import random
import webbrowser
import tkinter as tk
from tkinter import messagebox, filedialog

# Function to fetch a random video link from the Wayback Machine
def get_random_wayback_link():
    # Base URL for Wayback Machine
    wayback_url = "http://web.archive.org/cdx/search/cdx"

    # Fetching archived YouTube video links
    query = {
        'url': 'youtube.com/watch?v=*',
        'matchType': 'prefix',
        'filter': 'statuscode:200',
        'output': 'json',
        'limit': 500  # Fetching up to 500 random URLs
    }
    
    response = requests.get(wayback_url, params=query)

    if response.status_code == 200:
        data = response.json()
        # Remove header row, if any, then randomize and select one URL
        if len(data) > 1:
            random_entry = random.choice(data[1:])  # Skip the first element (header)
            wayback_link = f"http://web.archive.org/web/{random_entry[1]}/{random_entry[2]}"
            return wayback_link
        else:
            return None
    else:
        return None

# Function to open and download video from the random Wayback link
def download_video():
    random_link = get_random_wayback_link()
    if random_link:
        # Open the link in the browser (or you can use other tools to download it)
        webbrowser.open(random_link)
        messagebox.showinfo("Random Video Link", f"Video link: {random_link}")
    else:
        messagebox.showerror("Error", "Failed to retrieve a video link.")

# GUI for the Python form
def create_gui():
    window = tk.Tk()
    window.title("Wayback Random Video Downloader")
    window.geometry("400x200")
    
    label = tk.Label(window, text="Random Wayback Video Link Downloader", font=("Arial", 14))
    label.pack(pady=20)
    
    download_button = tk.Button(window, text="Download Random Video", command=download_video, bg="blue", fg="white")
    download_button.pack(pady=20)
    
    window.mainloop()

if __name__ == "__main__":
    create_gui()
