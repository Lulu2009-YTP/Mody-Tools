import requests
from bs4 import BeautifulSoup
import random
import yt_dlp

# Function to get archived YouTube links from Wayback Machine
def get_wayback_youtube_links(url):
    wayback_url = f"http://web.archive.org/cdx/search/cdx?url={url}&output=json&fl=original&collapse=urlkey"
    response = requests.get(wayback_url)
    data = response.json()
    
    links = [item[0] for item in data[1:]]
    return links

# Function to download a video from a given URL
def download_video(url):
    ydl_opts = {
        'outtmpl': '%(title)s.%(ext)s',  # Save file with the title of the video
        'format': 'bestvideo+bestaudio/best',  # Download best quality
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])

def main():
    youtube_url = 'youtube.com'  # Base YouTube URL to search archived versions
    links = get_wayback_youtube_links(youtube_url)
    
    if not links:
        print("No archived links found.")
        return
    
    random_link = random.choice(links)
    print(f"Selected URL: {random_link}")
    
    download_video(random_link)
    print("Download complete.")

if __name__ == "__main__":
    main()
