import tkinter as tk
from tkinter import filedialog
from wayback import get_random_url
from downloader import download_file

def download_random_file():
    file_type = file_type_entry.get()
    save_dir = filedialog.askdirectory()
    
    url = get_random_url(file_type)
    if url:
        download_file(url, save_dir)
        status_label.config(text=f"Downloaded: {url}")
    else:
        status_label.config(text="No file found!")

app = tk.Tk()
app.title("Wayback Random File Downloader")

tk.Label(app, text="Enter file type (zip/rar/wmv):").pack()
file_type_entry = tk.Entry(app)
file_type_entry.pack()

tk.Button(app, text="Download Random File", command=download_random_file).pack()
status_label = tk.Label(app, text="")
status_label.pack()

app.mainloop()
