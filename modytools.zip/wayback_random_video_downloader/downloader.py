import requests
import random
from pytube import YouTube

WAYBACK_URL = "http://web.archive.org/cdx/search/cdx?url=youtube.com/watch&output=json&fl=original&limit=100"

def get_random_youtube_url():
    response = requests.get(WAYBACK_URL)
    data = response.json()
    if len(data) > 1:
        # Randomly pick a YouTube URL from the Wayback data
        random_entry = random.choice(data[1:])
        return random_entry[0]
    return None

def download_video(youtube_url):
    try:
        yt = YouTube(youtube_url)
        stream = yt.streams.get_highest_resolution()
        print(f"Downloading video: {yt.title}")
        stream.download()
        print("Download completed.")
    except Exception as e:
        print(f"Failed to download video: {e}")

if __name__ == "__main__":
    url = get_random_youtube_url()
    if url:
        download_video(url)
    else:
        print("No valid YouTube URL found.")
