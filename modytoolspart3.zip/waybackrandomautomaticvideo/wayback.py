import requests
from bs4 import BeautifulSoup
import random

# Function to get archived YouTube links from Wayback Machine
def get_archived_links(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    links = []
    for a in soup.find_all('a', href=True):
        href = a['href']
        if 'youtube.com/watch' in href:
            links.append(href)
    
    return links

# Function to download a video (Placeholder function)
def download_video(video_url):
    print(f"Downloading video from {video_url}")
    # Use your preferred method or tool to download the video
    # Example: Use `youtube-dl` or `yt-dlp` to download the video
    # Command: `youtube-dl <video_url>`

# Main function
def main():
    # URL to the Wayback Machine page containing archived YouTube links
    wayback_url = 'https://web.archive.org/web/*/youtube.com'
    
    print("Fetching archived YouTube links from Wayback Machine...")
    links = get_archived_links(wayback_url)
    
    if links:
        print(f"Found {len(links)} links. Selecting a random link...")
        random_link = random.choice(links)
        print(f"Selected link: {random_link}")
        download_video(random_link)
    else:
        print("No YouTube links found.")

if __name__ == "__main__":
    main()
